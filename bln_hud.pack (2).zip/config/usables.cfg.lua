Usables = {}

Usables.items = {
    -- --------------------------------------------
    --  Example usable item
    -- --------------------------------------------
    -- ["item_name"] = {
    --     name = "Item Name",          -- Name of the item
    --     keepWhenUse = true,          -- Keep item when used, useful for items that are permenant
    --     hunger = 0,
    --     thirst = 15,
    --     urine = 10,                  -- Urine value to add when consuming this item (typically from drinks)
    --     stress = -5,
    --     tempModifier = {     -- Apply Temperature modification effect
    --         value = -2,      -- negative values cool down, positive values heat up
    --         duration = 20000 -- Effect duration in milliseconds (20 seconds)
    --     },
    --     snakePoisonAntidote = true, -- Enable or disable snake poison antidote
    --     player = {
    --         healthCore = 0,          -- Core health value
    --         staminaCore = 0,         -- Core stamina value
    --         healthOuter = 0,         -- Health outer value
    --         boostHealth = { 0, 0 },  -- {inner, outer} seconds
    --         boostStamina = { 0, 0 }, -- {inner, outer} seconds
    --     },
    --     horse = {
    --         healthCore = 0,          -- Core health value
    --         staminaCore = 0,         -- Core stamina value
    --         healthOuter = 0,         -- Health outer value
    --         boostHealth = { 0, 0 },  -- {inner, outer} seconds
    --         boostStamina = { 0, 0 }, -- {inner, outer} seconds
    --     },
    --     effects = {
    --         enabled = true,           -- Enable or disable animation
    --         animationName = "drink",  -- eat, drink, smoke, etc.
    --         screenFx = "",            -- Optional Screen effect to play
    --         prop = "P_BOTTLE008X",    -- Optional prop model to use for animation
    --         buffEffect = {"PlayerBoostBuff", 10} -- Optional buff effect to apply, {effectName, duration in seconds}
    --     },
    --     drunk = {                     -- Optional per-item drunk settings (overrides global Config.Drunk.min/max)
    --         min = 1,                  -- Minimum drinks needed to start getting drunk (uses global if not specified)
    --         max = 4,                  -- Maximum drinks needed to become very drunk (uses global if not specified)
    --         intensity = 1,             -- How much this drink adds to drunk level (default: 1)
    --     },
    --     returnItems = {              -- Items to give back after use
    --         { name = "item_name", label = "Item Label" amount = 1 }
    --     },
    --     requiredItems = { -- Items required to use this
    --         { name = "item_name", label = "Item Label" amount = 1 }
    --     },
    --     cooldown = false, -- cooldown in milliseconds, `false` to disable.
    --     useOnMount = false, -- Allow to use the item on a mount or not, default is true.
    --     ClientAction = function()
    --         -- Optional custom client actions
    --     end,
    --     ServerAction = function(source)
    --         -- Optional custom server actions
    --     end,
    --     useCondition = function(playerData) -- Optional condition to check before using the item
    --         -- -------
    --         -- playerData: id, identifier, job (name, grade), cash
    --         -- -------
    --         -- Example for job lock
    --         if playerData.job.name == 'medic' then
    --             return true
    --         else
    --             return false, "Only medics can use this item."
    --         end
    --     end
    -- },

    -- -------------------------------------------------------
    --  Main items
    -- -------------------------------------------------------
    ['water']                      = {
        name = "Water",
        hunger = 0,
        thirst = 20,
        urine = 15,
        stress = -5,
        tempModifier = {
            value = -2,
            duration = 20000
        },
        player = {
            healthCore = 0,
            staminaCore = 0,
        },
        effects = {
            enabled = true,
            animationName = "drink",
        },
    },

    ['milk']                       = {
        name = "Milk",
        hunger = 0,
        thirst = 10,
        urine = 8,
        stress = -3,
        player = {
            healthCore = 2,
        },
        effects = {
            enabled = true,
            animationName = "drink",
        },
    },

    ["apple"]                      = {
        name = "Apple",
        hunger = 25,
        thirst = 20,
        stress = -3,
        player = {
            healthCore = 2,
            healthOuter = 15,
        },
        effects = {
            enabled = true,
            animationName = "eatApple",
        },
        returnItems = {
            { name = "Apple_Seed", label = "Apple Seeds", amount = 1 }
        }
    },
    ["consumable_peach"]           = {
        name = "Peach",
        hunger = 20,
        thirst = 10,
        stress = -3,
        player = {
            healthCore = 2,
            healthOuter = 15,
        },
        effects = {
            enabled = true,
            animationName = "eatApple",
            prop = "s_peach01x"
        },
        returnItems = {
            { name = "peachseeds", label = "Peach Seeds", amount = 1 }
        }
    },

    ["sandwich"]                   = {
        name = "Sandwich",
        hunger = 25,
        thirst = -5,
        stress = -3,
        player = {
            healthCore = 3,
            healthOuter = 10,
        },
        effects = {
            enabled = true,
            animationName = "eatSandwich",
        }
    },

    ["watermelon"]                 = {
        name = "Watermelon",
        hunger = 30,
        thirst = 25,
        stress = -3,
        player = {
            healthCore = 2,
            healthOuter = 12,
        },
        effects = {
            enabled = true,
            animationName = "eatWatermelon",
        }
    },

    ["cheese"]                     = {
        name = "Cheese",
        hunger = 15,
        thirst = -3,
        stress = -2,
        player = {
            healthCore = 2,
            healthOuter = 8,
        },
        effects = {
            enabled = true,
            animationName = "eatCheese",
        }
    },

    ["bread"]                      = {
        name = "Bread",
        hunger = 15,
        thirst = -3,
        stress = -2,
        player = {
            healthCore = 2,
            healthOuter = 8,
        },
        effects = {
            enabled = true,
            animationName = "eatBread",
        }
    },

    ["banana"]                     = {
        name = "Banana",
        hunger = 20,
        thirst = 15,
        stress = -3,
        player = {
            healthCore = 2,
            healthOuter = 10,
        },
        effects = {
            enabled = true,
            animationName = "eatBanana",
        }
    },

    ["blackberry"]                 = {
        name = "Blackberry",
        hunger = 12,
        thirst = 10,
        stress = -2,
        player = {
            healthCore = 1,
            healthOuter = 8,
        },
        effects = {
            enabled = true,
            animationName = "eatBlackberry",
        },
        returnItems = {
            { name = "Black_Berry_Seed", label = "Blackberry Seeds", amount = 1 }
        }
    },

    -- This item is used for both player and horse
    ["carrot"]                     = {
        name = "Carrot",
        hunger = 15,
        thirst = 8,
        stress = -2,
        player = {
            healthCore = 2,
            healthOuter = 10,
        },
        horse = {
            healthCore = 10,
            staminaCore = 15,
        },
        effects = {
            enabled = true,
            animationName = "eatCarrot",
        }
    },

    -- Coffee example
    ["consumable_coffee"]          = {
        name = "Coffee",
        hunger = 0,
        thirst = 12,
        urine = 10,
        stress = -10,
        tempModifier = {
            value = 3,
            duration = 25000
        },
        player = {
            staminaCore = 5,
        },
        effects = {
            enabled = true,
            animationName = "coffee",
        },
    },

    -- Stew example
    ["chicken_stew"]               = {
        name = "Chicken Stew",
        hunger = 82,
        thirst = 70,
        stress = 0,
        player = {
            healthCore = 2,
        },
        effects = {
            enabled = true,
            animationName = "eatStew",
        }
    },

    -- Canned food example
    ["consumable_kidneybeans_can"] = {
        name = "Kidneybeans Can",
        hunger = 4,
        thirst = 2,
        stress = 0,
        player = {
            healthCore = 3,
        },
        effects = {
            enabled = true,
            animationName = "eatCannedFood",
        }
    },

    -- Pomade example
    ["pomade"]                     = {
        name = "Pomade",
        hunger = 0,
        thirst = 0,
        stress = -2,
        effects = {
            enabled = true,
            animationName = "pomade",
            screenFx = ""
        },
    },

    -- -------------------------------------------------------
    --  Medicine/Bandage/Heal examples
    -- -------------------------------------------------------
    -- Stim example
    ["stim"]                       = {
        name = "Stimulant",
        hunger = 0,
        thirst = 0,
        stress = -2,
        player = {
            healthCore = 45,
            healthOuter = 15,
            staminaCore = 34,
        },
        effects = {
            enabled = true,
            animationName = "inject",
        },
        cooldown = 60000,
    },

    -- Medicine example
    ["consumable_medicine"]        = {
        name = "Medicine",
        hunger = 0,
        thirst = 0,
        stress = -5,
        snakePoisonAntidote = true,
        player = {
            healthCore = 20,
        },
        effects = {
            enabled = true,
            animationName = "medicine",
        },
        ClientAction = function()
            TriggerEvent('bln_hud:UseSnakeAntidote') -- Use antidote to cure snake poison
        end,
        cooldown = 30000,
    },

    -- Bandage example
    ["bandage"]                    = {
        name = "Bandage",
        hunger = 0,
        thirst = 0,
        stress = -2,
        player = {
            healthCore = 35,
        },
        effects = {
            enabled = true,
            animationName = "bandage",
        },
        useOnMount = false,
        cooldown = 60000,
    },

    -- -------------------------------------------------------
    --  Tobacco/Smoking items examples
    -- -------------------------------------------------------
    -- Cigarette example
    ["cigarette"]                  = {
        name = "Cigarette",
        hunger = -2,
        thirst = -5,
        stress = -20,
        player = {
            staminaCore = 5,
        },
        effects = {
            enabled = true,
            animationName = "cigarette",
        },
        requiredItems = {
            { name = "matches", label = "Matches", amount = 1 }
        }
    },

    -- Cigar example
    ["cigar"]                      = {
        name = "Cigar",
        hunger = -3,
        thirst = -8,
        stress = -25,
        player = {
            staminaCore = 8,
        },
        effects = {
            enabled = true,
            animationName = "cigar",
        },
        requiredItems = {
            { name = "lighter", label = "Lighter", amount = 1 }
        }
    },

    -- Pipe example
    ["pipe"]                       = {
        name = "Pipe",
        hunger = -2,
        thirst = -5,
        stress = -15,
        player = {
            staminaCore = 5,
        },
        effects = {
            enabled = true,
            animationName = "pipe",
        },
        requiredItems = {
            { name = "matches", label = "Matches", amount = 1 }
        }
    },

    -- Peace pipe example
    ["pipepeace"]                  = {
        name = "Peace Pipe",
        hunger = -2,
        thirst = -5,
        stress = -15,
        player = {
            staminaCore = 5,
            boostStamina = { 10, 5 },
        },
        effects = {
            enabled = true,
            animationName = "peacepipe",
            prop = "p_peacepipe01x"
        },
        requiredItems = {
            { name = "matches", label = "Matches", amount = 1 }
        }
    },

    ["pipepeace2"]                 = {
        name = "Peace Pipe",
        hunger = -2,
        thirst = -5,
        stress = -15,
        player = {
            staminaCore = 5,
            boostStamina = { 10, 5 },
        },
        effects = {
            enabled = true,
            animationName = "peacepipe",
            prop = "p_peacepipe02x"
        },
        requiredItems = {
            { name = "matches", label = "Matches", amount = 1 }
        }
    },


    -- Chewing tobacco example
    ["chewingtobacco"] = {
        name = "Chewing Tobacco",
        hunger = -2,
        thirst = -5,
        stress = -15,
        player = {
            staminaCore = 12,
            boostStamina = { 10, 5 },
        },
        effects = {
            enabled = true,
            animationName = "chew_tobacco",
        }
    },
    -- -------------------------------------------------------
    --  Alcohol examples
    -- -------------------------------------------------------
    ["beer"]           = {
        name = "Beer",
        hunger = 5,
        thirst = 20,
        urine = 18,
        stress = -10,
        effects = {
            enabled = true,
            animationName = "alcohol", -- normal alcohol
        },
        drunk = {
            min = 2,       -- Beer requires 2 drinks to start feeling drunk
            max = 5,       -- 5 beers to reach very drunk state
            intensity = 1, -- Each beer adds 1 to drunk level
        },
    },

    ["wine"]           = {
        name = "Wine",
        hunger = 2,
        thirst = 15,
        urine = 14,
        stress = -12,
        effects = {
            enabled = true,
            animationName = "alcoholblackout", -- Player may wake up in random location
        },
        drunk = {
            min = 1,       -- Wine is stronger, 1 drink starts effects
            max = 3,       -- 3 wines to reach very drunk state
            intensity = 1, -- Each wine adds 1 to drunk level
        },
    },
    -- -------------------------------------------------------
    --  Horse items examples
    -- -------------------------------------------------------
    -- Horse feed example
    ["hay"]            = {
        name = "Hay",
        horse = {
            healthCore = 10,
            staminaCore = 15,
        },
        effects = {
            enabled = true,
            animationName = "horsefeed",
            prop = "p_handfulofhay"
        }
    },


    -- Horse medicine/boost example
    ["horsestim"]         = {
        name = "Horse Stimulant",
        horse = {
            healthCore = 50,
            staminaCore = 50,
            boostStamina = { 10, 0 },
            boostHealth = { 10, 0 },
        },
        effects = {
            enabled = true,
            animationName = "horseinject",
        }
    },

    -- Horse brush example
    ["horsebrush"]        = {
        name = "Horse Brush",
        keepWhenUse = true,
        horse = {
            healthCore = 5,
        },
        effects = {
            enabled = true,
            animationName = "horsebrush",
        },
    },

    -- -------------------------------------------------------
    --  Tonic examples
    -- -------------------------------------------------------
    ["golden_tonic"]      = {
        name = "Golden Tonic",
        hunger = 0,
        thirst = 0,
        player = {
            boostHealth = { 10, 10 },
            boostStamina = { 10, 10 },
        },
        effects = {
            enabled = true,
            animationName = "drink",
            prop = "s_craftedtonic_02x",
        },
        cooldown = 120000, -- 2 minutes cooldown for powerful tonic
    },

    ["health_tonic"]      = {
        name = "Health Tonic",
        hunger = 0,
        thirst = 0,
        player = {
            boostHealth = { 10, 10 },
            boostStamina = { 0, 0 },
        },
        effects = {
            enabled = true,
            animationName = "drink",
            prop = "s_craftedtonic_02x",
        },
    },

    ["stamina_tonic"]     = {
        name = "Stamina Tonic",
        hunger = 0,
        thirst = 0,
        player = {
            boostHealth = { 0, 0 },
            boostStamina = { 10, 10 },
        },
        effects = {
            enabled = true,
            animationName = "drink",
            prop = "s_craftedtonic_02x",
        },
    },
    -- -------------------------------------------------------
    --  Pocket Watch example
    -- -------------------------------------------------------
    -- Prop         : s_inv_pocketwatch01x, s_inv_pocketwatch02x, s_inv_pocketwatch03x, s_inv_pocketwatch04x
    -- Default prop : s_inv_pocketwatch03x (gold)
    -- -------------------------------------------------------
    ["pocket_watch"]      = {
        name = "Pocket Watch",
        keepWhenUse = true,
        effects = {
            enabled = true,
            animationName = "pocketwatch",
            prop = "s_inv_pocketwatch01x"
        },
    },
    ["pocket_watch_gold"] = {
        name = "Pocket Watch Gold",
        keepWhenUse = true,
        effects = {
            enabled = true,
            animationName = "pocketwatch",
            prop = "s_inv_pocketwatch03x"
        },
    },

    -- -------------------------------------------------------
    --  Buff examples
    -- -------------------------------------------------------
    ["playerbuff"]        = {
        name = "Player Buff",
        hunger = 0,
        thirst = 0,
        stress = -2,
        player = {
            healthCore = 45,
            healthOuter = 15,
            staminaCore = 34,
            boostStamina = { 60, 0 },
            boostHealth = { 60, 0 },
        },
        effects = {
            enabled = true,
            animationName = "inject",
            buffEffect = { "PlayerBoostBuff", 60 }
        },
    },

    ["horsebuff"]         = {
        name = "Horse Buff",
        hunger = 0,
        thirst = 0,
        stress = -2,
        horse = {
            healthCore = 45,
            staminaCore = 34,
            boostStamina = { 60, 0 },
            boostHealth = { 60, 0 },
        },
        effects = {
            enabled = true,
            animationName = "inject",
            buffEffect = { "HorseBoostBuff", 60 }
        },
    },
}
